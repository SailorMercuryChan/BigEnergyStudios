﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHandler : MonoBehaviour {

    //Cached Reference
    EnemyInfo enemyInfo;
    EnemyBehaviour enemyBehaviour;
    Level level;

    //Spawn
    public Transform spawnPosition;
    

    //Arrays
    public GameObject[] enemies;
    
 
    private void Start()
    {
        enemyInfo = FindObjectOfType<EnemyInfo>();
        enemyBehaviour = FindObjectOfType<EnemyBehaviour>();
        level = FindObjectOfType<Level>();
        SpawnEnemies();
        

       
    }

    void Update()
    {
        if (level.enemyCount <= 0)
        {
            SpawnEnemies();
        }
    }


    public void SpawnEnemies()
    {
        for (int i = 0; i < enemyInfo.EnemyEndCoordnates.Length; i++)
        {
            enemies[i] = Instantiate(enemyInfo.enemy2, spawnPosition);
            enemies[i].GetComponent<EnemyBehaviour>().enemyFormationCoordinates = enemyInfo.EnemyEndCoordnates[i];



        }
    }

}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameLogic : MonoBehaviour {

    public int lives;
    public int score;
    public int stageNumber;
    public int ScoreUntilNextLife;






    // Use this for initialization
    void Start () {
        lives = 3;
        score = 0;
        ScoreUntilNextLife = 1500;
	}
	
	// Update is called once per frame
	void Update () {

        if (score == ScoreUntilNextLife)
        {
            lives = lives + 1;
        }
		
	}
}

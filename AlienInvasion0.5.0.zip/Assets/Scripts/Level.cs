﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level : MonoBehaviour {

    public int enemyCount;


    //Cached 
    SceneLoader sceneloader;

    private void Start()
    {
        sceneloader = FindObjectOfType<SceneLoader>();
        enemyCount = enemyCount - 1;
    }

    public void CountEnemies()
    {
        enemyCount++;
    }

    public void DestroyEnemy()
    {
        enemyCount = enemyCount - 1;
        
    }
	
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShipControl : MonoBehaviour
{

    //Player ship variables
    private Rigidbody2D playerRB;
    [SerializeField] float playerSpeed;
    [SerializeField] float leftBound = 0f;
    [SerializeField] float rightBound = 13.3333f;
    

    

    //Bullet Variables
    [SerializeField] GameObject bullet;
    private Rigidbody2D bulletRB;
    private int bulletCloneCount;
    [SerializeField] private int playerBulletSpeed;
    [SerializeField] private float fireRate;
    [SerializeField] private float nextTimeToFire;



    [SerializeField] float screenWidthInUnits = 13.333f;


    // Use this for initialization
    void Start()
    {
        bulletRB = bullet.GetComponent<Rigidbody2D>();
        playerRB = gameObject.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        PlayerShoot();
        PlayerMove();

        
            
 
        
    }

    private void PlayerShoot()
    {
        if (Input.GetKeyDown(KeyCode.Mouse0) && Time.time >= nextTimeToFire)
        {

            Rigidbody2D bulletClone;
            bulletClone = Instantiate(bulletRB, transform.position, transform.rotation);
            bulletClone.velocity = transform.TransformDirection(Vector2.up * playerBulletSpeed);   
            nextTimeToFire = Time.time + fireRate;
            
            }
        }

    //This function defines player movement and ship boundaries
    private void PlayerMove()
    {
        float mousePosInUnits = (Input.mousePosition.x / Screen.width * screenWidthInUnits);
        Vector2 playerPos = new Vector2(mousePosInUnits, transform.position.y);
        playerPos.x = Mathf.Clamp(mousePosInUnits, leftBound, rightBound);
        transform.position = playerPos;


        

        
      
        
    }
}

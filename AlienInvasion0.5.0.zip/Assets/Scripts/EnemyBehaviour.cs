﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class EnemyBehaviour : MonoBehaviour {

    //Cached references
    GameLogic gamelogic;
    Level level;
    EnemyHandler enemyHandler;
    



    //collider and bullet
    [SerializeField] GameObject enemyBullet;
    private Collider2D enemyCollider;
    private Rigidbody2D enemyRB;
    private Rigidbody2D bulletRB;
    [SerializeField] int enemyBulletSpeed;


    //Enemy Movement Stuff
    [SerializeField] int EnemySpeed;
    public Vector2 enemyFormationCoordinates;

    // Use this for initialization
    void Start() {
        
        bulletRB = enemyBullet.GetComponent<Rigidbody2D>();
        enemyRB = gameObject.GetComponent<Rigidbody2D>();
        gamelogic = FindObjectOfType<GameLogic>();
        level = FindObjectOfType<Level>();
        level.CountEnemies();
        enemyHandler = FindObjectOfType<EnemyHandler>();
        

    }
   

    // Update is called once per frame
    void Update() {
     
        if (Input.GetKey("f"))
        {
            enemyShoot();
        }

        GoToFormationPosition();

    }


    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag.Equals("PlayerBullet")) 
        {
            gamelogic.score = gamelogic.score + 10;
            Destroy(gameObject);
            level.DestroyEnemy();


        }
    }

    private void enemyShoot()
    {
        Rigidbody2D bulletClone;
        bulletClone = Instantiate(bulletRB, transform.position, transform.rotation);
        bulletClone.velocity = transform.TransformDirection(Vector2.down * enemyBulletSpeed);
     
    }

    private void GoToFormationPosition()
    {
        transform.position = Vector2.Lerp(transform.position, enemyFormationCoordinates, Time.deltaTime);
    }




    
}

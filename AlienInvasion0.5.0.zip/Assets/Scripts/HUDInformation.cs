﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class HUDInformation : MonoBehaviour {

    public GameLogic gameLogic;

    public Text scoreText;
    public Text hiScoreText;
    public Text lives;


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        scoreText.text = "score: " + gameLogic.score;

        lives.text = "Lives: " + gameLogic.lives;
	}
}

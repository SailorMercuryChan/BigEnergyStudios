﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyInfo : MonoBehaviour
{



    //Arrays
    public Vector2[] EnemyEndCoordnates;

    //EnemyTypes
    public GameObject enemy1;
    public GameObject enemy2;
    public GameObject enemy3;



    private void Start()
    {
        //EnemyEndCorrdinateInfo, corrdinates are from top to bottom to the right
        EnemyEndCoordnates = new Vector2[40];

        EnemyEndCoordnates[0] = new Vector2(2f, 6.75f);
        EnemyEndCoordnates[1] = new Vector2(2f, 6.25f);
        EnemyEndCoordnates[2] = new Vector2(3.10f, 7.25f);
        EnemyEndCoordnates[3] = new Vector2(3.10f, 6.75f);
        EnemyEndCoordnates[4] = new Vector2(3.10f, 6.25f);
        EnemyEndCoordnates[5] = new Vector2(4.20f, 7.75f);
        EnemyEndCoordnates[6] = new Vector2(4.20f, 7.25f);
        EnemyEndCoordnates[7] = new Vector2(4.20f, 6.75f);
        EnemyEndCoordnates[8] = new Vector2(4.20f, 6.25f);
        EnemyEndCoordnates[9] = new Vector2(5.30f, 8.25f);
        EnemyEndCoordnates[10] = new Vector2(5.30f, 7.75f);
        EnemyEndCoordnates[11] = new Vector2(5.30f, 7.25f);
        EnemyEndCoordnates[12] = new Vector2(5.30f, 6.75f);
        EnemyEndCoordnates[13] = new Vector2(5.30f, 6.25f);
        EnemyEndCoordnates[14] = new Vector2(6.40f, 8.25f);
        EnemyEndCoordnates[15] = new Vector2(6.40f, 7.75f);
        EnemyEndCoordnates[16] = new Vector2(6.40f, 7.25f);
        EnemyEndCoordnates[17] = new Vector2(6.40f, 6.75f);
        EnemyEndCoordnates[18] = new Vector2(6.40f, 6.25f);
        EnemyEndCoordnates[19] = new Vector2(7.50f, 8.25f);
        EnemyEndCoordnates[20] = new Vector2(7.50f, 7.75f);
        EnemyEndCoordnates[21] = new Vector2(7.50f, 7.25f);
        EnemyEndCoordnates[22] = new Vector2(7.50f, 6.75f);
        EnemyEndCoordnates[23] = new Vector2(7.50f, 6.25f);
        EnemyEndCoordnates[24] = new Vector2(8.60f, 8.25f);
        EnemyEndCoordnates[25] = new Vector2(8.60f, 7.75f);
        EnemyEndCoordnates[26] = new Vector2(8.60f, 7.25f);
        EnemyEndCoordnates[27] = new Vector2(8.60f, 6.75f);
        EnemyEndCoordnates[28] = new Vector2(8.60f, 6.25f);
        EnemyEndCoordnates[29] = new Vector2(9.70f, 7.75f);
        EnemyEndCoordnates[30] = new Vector2(9.70f, 7.25f);
        EnemyEndCoordnates[31] = new Vector2(9.70f, 6.75f);
        EnemyEndCoordnates[32] = new Vector2(9.70f, 6.25f);
        EnemyEndCoordnates[33] = new Vector2(10.80f, 7.75f);
        EnemyEndCoordnates[34] = new Vector2(10.80f, 7.25f);
        EnemyEndCoordnates[35] = new Vector2(10.80f, 6.75f);
        EnemyEndCoordnates[36] = new Vector2(10.80f, 6.25f);
        EnemyEndCoordnates[37] = new Vector2(11.90f, 6.75f);
        EnemyEndCoordnates[38] = new Vector2(11.90f, 6.25f);
        EnemyEndCoordnates[39] = new Vector2(12f, 6.75f);
        

    }

}

    
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class EnemyBehaviour : MonoBehaviour {

    //Cached references
    GameLogic gamelogic;
    Level level;




    //collider and bullet
    [SerializeField] GameObject enemyBullet;
    private Collider2D enemyCollider;
    private Rigidbody2D enemyRB;
    private Rigidbody2D bulletRB;
    [SerializeField] int enemyBulletSpeed;



    [SerializeField] int EnemySpeed;


    // Use this for initialization
    void Start() {
        bulletRB = enemyBullet.GetComponent<Rigidbody2D>();
        enemyRB = gameObject.GetComponent<Rigidbody2D>();
        gamelogic = FindObjectOfType<GameLogic>();
        level = FindObjectOfType<Level>();
        level.CountEnemies();
    }
   

    // Update is called once per frame
    void Update() {
     
        if (Input.GetKey("f"))
        {
            enemyShoot();
        }
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag.Equals("PlayerBullet")) 
        {
            gamelogic.score = gamelogic.score + 10;
            level.DestroyEnemy();
            Destroy(gameObject);
           

        }
    }

    private void enemyShoot()
    {
        Rigidbody2D bulletClone;
        bulletClone = Instantiate(bulletRB, transform.position, transform.rotation);
        bulletClone.velocity = transform.TransformDirection(Vector2.down * enemyBulletSpeed);
     
    }




    
}

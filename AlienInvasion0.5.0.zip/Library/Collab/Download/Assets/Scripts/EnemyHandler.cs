﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHandler : MonoBehaviour {


    //Column variables
    [SerializeField] int numberOfColumns = 5;
    [SerializeField] int enemiesPerColumn;
    public int enemyVerticalDistance;
    [SerializeField] GameObject startingColumn;
    [SerializeField] float columnSpacing;

    public GameObject enemy1;
    public GameObject enemy2;
    public GameObject enemy3;

    //Stores all columns
    public GameObject[] columns;


    //Stores enemies for each column
    public GameObject[] enemies;

    //Stores enemy formation cordinates
    public Vector2[] enemyFormationCordinates;


    // Use this for initialization
    void Start ()
    {

        Transform startingColumnPosition = startingColumn.GetComponent<Transform>();

        EnemyWaveGenerator(startingColumnPosition);

    }

     void EnemyWaveGenerator(Transform startingColumnPosition)
    {

        for (int i = 0; i <= numberOfColumns; i++)
        {

          columns[i] = Instantiate(startingColumn, new Vector2(startingColumnPosition.position.x + (columnSpacing * i), startingColumnPosition.position.y), Quaternion.identity);
            

            for (int j = 0; j <= enemiesPerColumn / 2; j++)
            {
             enemies[j] =  Instantiate(enemy1, new Vector2(startingColumnPosition.position.x + (columnSpacing * i), startingColumnPosition.position.y - (enemyVerticalDistance * j)), Quaternion.identity);
            }

            for (int j = (enemiesPerColumn / 2) + 1; j <= enemiesPerColumn; j++)
            {
                enemies[j] = Instantiate(enemy2, new Vector2(startingColumnPosition.position.x + (columnSpacing * i), startingColumnPosition.position.y - (enemyVerticalDistance * j)), Quaternion.identity);
                enemies[j] = columns[i];
            }
            

        }
    }

    // Update is called once per frame
    void Update () {
		
	}

    
}
